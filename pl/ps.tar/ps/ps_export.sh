export LD_LIBRARY_PATH=`pwd`:$LD_LIBRARY_PATH    
export LD_PRELOAD="./libprocps.so.4"
chmod 777 ./ps
./ps